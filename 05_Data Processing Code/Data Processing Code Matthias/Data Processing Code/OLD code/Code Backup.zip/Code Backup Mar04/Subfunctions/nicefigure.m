function nicefigure(purpose)

switch purpose
    
    case 'thesis'
        set(gca, 'FontName','Times New Roman','FontSize',12,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 4, 6.5, 4.5]);
        
    case 'paper'
        set(gca, 'FontName','Times New Roman','FontSize',10,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 4, 3.5, 2.5]);
        title('')
        
    case 'presentation'
        set(gca, 'FontName','Times New Roman','FontSize',10,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 4, 4.75, 4]);
        
         case 'presentation_x2'
        set(gca, 'FontName','Times New Roman','FontSize',20,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 0, 4.75*2, 4*2]);
   
end
