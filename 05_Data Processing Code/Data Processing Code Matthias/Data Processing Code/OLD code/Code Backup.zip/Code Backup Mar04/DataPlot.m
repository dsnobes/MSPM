%% SECTION 1: Data import %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RUN THIS SECTION FIRST. No inputs required.
% clear, close all
[DATA_EXP, DATA_MOD] = DataPlot_import; % calls subfunction
fig_count = 1; % figure counter
figure_purpose = 'thesis';


%% SECTION 2: PV curve comparison %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SET INPUTS BELOW BEFORE RUNNING
% Run this section if you want to compute and plot the PV diagram
% comparison parameters for experimental and model datasets.

% INPUTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Whether to plot the PVs for each data point.
% 0 for no plots
% 1 to show each plot
% any number n > 1 to show every n'th plot
% > 0 always shows plots for 1st and last data point)
plotPVs = 20;

% SPECIFY the indices (in DATA_EXP and DATA_MOD) of the datasets that
% should be used for comparing PV shapes. Datasets will be compared in the
% order they appear in iPV_mod and iPV_exp. Experimental and model datasets
% being compared must have same number and order of datapoints.
% Can specify any number of pairs of datasets to be compared.

iPV_exp = 1:length(DATA_EXP); % indices of experimental datasets for comparison

iPV_mod = 1:length(DATA_MOD); % indices of model datasets for comparison

% END INPUTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Outputs: p_dev_max, p_dev_mean, PV_overlap_ratio
% Plots:
% (1) raw PV curves
% (2) Volume over crank angle, incl max volume deviation
% (3) Overlaid PV curves with overlap curve and percentage
[p_dev_max, p_dev_mean, PV_overlap_ratio] = DataPlot_PVcompare(plotPVs,figure_purpose,iPV_exp,iPV_mod, DATA_EXP,DATA_MOD);

close all

%% SECTION 3: PLOTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Each section here has one plot. Desciption in the section header.


%% Indicated Work %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Indicated Work vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Work [J]')
title('Indicated Work')
nicefigure(figure_purpose);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp: ' DATA_EXP(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp], 30, 'o', 'DisplayName',legname);
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)   
    legname = ['Mod: ' DATA_MOD(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, 'x', 'DisplayName',legname);
end

legend('Interpreter', 'none')

%% Indicated Work vs speed, pressure color coded, with colorbar
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Work [J]')
title('Indicated Work')
nicefigure(figure_purpose);
plots_i = 1;

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp: ' DATA_EXP(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp], 30, [DATA_EXP(i).data.pmean]./1000, 'o', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod: ' DATA_MOD(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, [DATA_EXP(i).data.pmean]./1000, 'x', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

legend(plots, 'Experiment','Model')
cb = colorbar;
ylabel(cb,'Mean Pressure (kPa)')
colormap(jet(10))



%% Indicated Work vs speed, pressure color coded, with colors in legend
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Work [J]')
title('Indicated Work')
nicefigure(figure_purpose);
plots_i = 1;

markers = {'o','sq'};
markers = repelem(markers,2);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp], 30, [DATA_EXP(i).data.pmean]./1000, markers{i}, 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, [DATA_EXP(i).data.pmean]./1000, 'x', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

legend('Interpreter', 'none')
colormap(jet(10))
% 

%% Shaft Power %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% P shaft vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 25;
xlabel('Speed [rpm]')
ylabel('Shaft Power [W]')
title('Shaft Power')
nicefigure(figure_purpose);
legend('Interpreter', 'none')

markers = {'o','sq'};
markers = repelem(markers,2);
colors = {'b','r'};
colors = repmat(colors,1,2);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp: ' DATA_EXP(i).name];
%     if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end   
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.P_shaft_exp_tsensor], 40, colors{i}, markers{i}, 'DisplayName',legname)
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod: ' DATA_MOD(i).name];
    scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.P_shaft], 30, 'x', 'DisplayName',legname)
end

%% P shaft vs speed, comparing measures of shaft power
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 25;
xlabel('Speed [rpm]')
ylabel('Shaft Power [W]')
title('Shaft Power')
nicefigure(figure_purpose);
legend('Interpreter', 'none')


% plot all experimental datapoints. different color for each dataset.
for i=1%:length(DATA_EXP)
    legname = ['Exp: ' 'Measured'];
%     if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end   
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.P_shaft_exp_tsensor], 40, 'g', 'sq', 'DisplayName',legname)
    legname = ['Exp: ' 'Setpoint'];
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.P_shaft_exp], 30, 'b', 'o', 'DisplayName',legname)


end
% plot all model datapoints. different color for each dataset.
for i=2%:length(DATA_MOD)
    legname = ['Mod: ' 'MSPM Power'];
    scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.P_shaft], 30, 'k', 'x', 'DisplayName',legname)
    for j = 1:length(DATA_MOD(i).data)
        P_calc(j) = (DATA_MOD(i).data(j).PV_PP.Wind + DATA_MOD(i).data(j).PV_Exp.Wind + DATA_MOD(i).data(j).PV_Com.Wind) * DATA_MOD(i).data(j).speedHz;
        P_calc_flowloss(j) = P_calc(j) - DATA_MOD(i).data(j).Qdot_flowloss;
    end
    legname = ['Mod: ' 'from PV data'];
    scatter([DATA_MOD(i).data.speedRPM], P_calc, 40, 'r', 'x', 'DisplayName',legname)
    legname = ['Mod: ' 'from PV data, flowloss'];
    scatter([DATA_MOD(i).data.speedRPM], P_calc_flowloss, 40, 'r', '+', 'DisplayName',legname)
 
    %     if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    
    %     plot([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind])%, 30, [DATA_MOD(i).data.p_mean]./1000)%,'x')
end

%% Efficiency %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Eff vs speed, pressure color coded, with colors in legend
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Efficiency [%]')
title('Efficiency (indicated)')
nicefigure(figure_purpose);
plots_i = 1;

markers = {'o','sq'};
markers = repelem(markers,2);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.efficiency_ind]*100, 30, [DATA_EXP(i).data.pmean]./1000, markers{i}, 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end

% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.efficiency_ind]*100, 40, [DATA_MOD(i).data.p_mean]./1000, 'x', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

legend('Interpreter', 'none')
colormap(jet(10))



%% Eff vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 40;
xlabel('Speed [rpm]')
ylabel('Indicated Efficiency [%]')
title('Efficiency (indicated)')
nicefigure(figure_purpose);
plots_i = 1;

for i=1:length(DATA_EXP)
    % MB_speed in rpm
    %eff_ind = [DATA_EXP(i).data.Wind_exp].*[DATA_EXP(i).data.MB_speed]./60 ./([DATA_EXP(i).data.Qdot_heater_exp]+[DATA_EXP(i).data.Qdot_DCH_exp]) *100; % [%]
    legname = ['Exp: ' DATA_EXP(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.efficiency_ind]*100, 30, 'o', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod: ' DATA_MOD(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.efficiency_ind]*100, 40, 'x', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

legend('Interpreter', 'none')

%% Heat Flow Rates vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Heat Flow [W]')
title('Heat Flow Rates')
nicefigure(figure_purpose);
plots_i = 1;

for i=1 % 450kpa
    legname = ['Exp: ' 'Heater'];
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Qdot_heater_exp], 30, 'r', 'o', 'DisplayName',legname);
    legname = ['Exp: ' 'Cooler'];
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Qdot_cooler_exp], 30, 'b', 'o', 'DisplayName',legname);
    legname = ['Exp: ' 'Shaft Power'];
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.P_shaft_exp_tsensor], 30, 'g', 'o', 'DisplayName',legname);
    legname = ['Exp: ' 'Lost'];
    Qlost = [DATA_EXP(i).data.Qdot_heater_exp]-[DATA_EXP(i).data.P_shaft_exp_tsensor]-[DATA_EXP(i).data.Qdot_cooler_exp];
    p = scatter([DATA_EXP(i).data.MB_speed], Qlost, 30, 'k', 'o', 'DisplayName',legname);
%     if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end
% plot all model datapoints. different color for each dataset.
markers = {'x','+','*'};
legs = {'FinConn (old) ','FinEnh insulated','FinEnh custom h'};
for i=1:3 
    legname = [legs{i} 'Source' ];
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Qdot_fromSource], 40, 'r', markers{i}, 'DisplayName',legname);
    legname = [legs{i} 'Sink' ];
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Qdot_toSink], 40, 'b', markers{i}, 'DisplayName',legname);
    legname = [legs{i} 'Shaft Power' ];
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.P_shaft], 40, 'g', markers{i}, 'DisplayName',legname);
    legname = [legs{i} 'Environment' ];
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Qdot_toEnv], 40, 'k', markers{i}, 'DisplayName',legname);
    legname = [legs{i} 'Other Loss' ];
    loss = [DATA_MOD(i).data.Qdot_fromSource]-[DATA_MOD(i).data.Qdot_toSink]-[DATA_MOD(i).data.P_shaft]-[DATA_MOD(i).data.Qdot_toEnv];
    p = scatter([DATA_MOD(i).data.speedRPM], loss, 40, [0.5 0.5 0.5], markers{i}, 'DisplayName',legname);
%     if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

legend('Interpreter', 'none')


%% Gas Temperatures (Avg) vs speed

% Hot Side %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(fig_count);
fig_count = fig_count+1;
hold on
xlabel('Speed [rpm]')
ylabel('Gas Temperature [\circC]')
legend('Interpreter', 'none')
title('Gas Temperatures (TC), hot side. x - model, o - experiment (inc torque), sq - experiment (dec torque)')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated n times.
C = get(gca,'ColorOrder');
magenta = [1 0 1];
black = [0 0 0];
green = [0 1 0];
C = [C; magenta; black; green];
% C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all experimental datapoints. different color for each dataset.
markers = {'o','sq'};
for i=1:length(DATA_EXP)
    x = [DATA_EXP(i).data.MB_speed];
    scatter(x, [DATA_EXP(i).data.Tge_exp], 30, markers{i}, 'DisplayName','Tge_exp (TC0)')
    scatter(x, [DATA_EXP(i).data.Tgh_inlet_far], 30, markers{i}, 'DisplayName','Tgh_inlet_far (TC1)')
    scatter(x, [DATA_EXP(i).data.Tgh_inlet_pipe], 30, markers{i}, 'DisplayName','Tgh_inlet_pipe (TC2)')
    scatter(x, [DATA_EXP(i).data.Tgh_inlet], 30, markers{i}, 'DisplayName','Tgh_inlet (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_reg_far], 30, markers{i}, 'DisplayName','Tgh_reg_far (TC3)')
    scatter(x, [DATA_EXP(i).data.Tgh_reg_pipe], 30, markers{i}, 'DisplayName','Tgh_reg_pipe (TC4)')
    scatter(x, [DATA_EXP(i).data.Tgh_reg], 30, markers{i}, 'DisplayName','Tgh_reg (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_exp_far], 30, markers{i}, 'DisplayName','Tgh_exp_far (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_exp_pipe], 30, markers{i}, 'DisplayName','Tgh_exp_pipe (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_exp], 30, markers{i}, 'DisplayName','Tgh_exp (avg)')
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    x = [DATA_MOD(i).data.speedRPM];
    % plot mean of each setpoint
    scatter(x, mean([DATA_MOD(i).data.Tge]), 40, C(1,:), 'x', 'DisplayName','Tge')
    scatter(x, mean([DATA_MOD(i).data.Tgh_inlet]), 40, C(4,:), 'x','DisplayName','Tgh_inlet') 
    scatter(x, mean([DATA_MOD(i).data.Tgh_reg]), 40, C(7,:), 'x','DisplayName','Tgh_reg') 
    scatter(x, mean([DATA_MOD(i).data.Tgh_reg_TopOfReg_test]), 40, C(7,:), '+','DisplayName','Tgh_reg_TopOfReg_test') 
    scatter(x, mean([DATA_MOD(i).data.Tgh_center]), 40, C(10,:), 'x','DisplayName','Tgh_center') 
end

% regenerator %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(fig_count);
fig_count = fig_count+1;
hold on
xlabel('Speed [rpm]')
ylabel('Gas Temperature [\circC]')
legend('Interpreter', 'none')
title('Gas Temperatures (TC), Regenerator. x - model, o - experiment (inc torque), sq - experiment (dec torque)')
nicefigure(figure_purpose);

markers = {'o','sq'};
for i=1:length(DATA_EXP)
    x = [DATA_EXP(i).data.MB_speed];
%     scatter(x, [DATA_EXP(i).data.Tgh_reg_far], 30, markers{i}, 'DisplayName','Tgh_reg_far')
%     scatter(x, [DATA_EXP(i).data.Tgh_reg_pipe], 30, markers{i}, 'DisplayName','Tgh_reg_pipe')
%     scatter(x, [DATA_EXP(i).data.Tgh_reg], 30, markers{i}, 'DisplayName','Tgh_reg')
    scatter(x, [DATA_EXP(i).data.Tgr_exp], 30, markers{i}, 'DisplayName','Tgr_exp (log mean Tgh_reg, Tgk_reg)')
%     scatter(x, [DATA_EXP(i).data.Tgk_reg], 30, markers{i}, 'DisplayName','Tgk_reg')
end

for i=1:length(DATA_MOD)
    x = [DATA_MOD(i).data.speedRPM];
    scatter(x, mean([DATA_MOD(i).data.Tgr_center]), 40, 'x','DisplayName','Tgr_center') 
    scatter(x, [DATA_MOD(i).data.Tgr_log], 40, 'x','DisplayName','Tgr_log (log mean Tgh_reg, Tgk_reg)') 
end

% Cold Side %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(fig_count);
fig_count = fig_count+1;
hold on
xlabel('Speed [rpm]')
ylabel('Gas Temperature [\circC]')
legend('Interpreter', 'none')
title('Gas Temperatures (TC), cold side. x - model, o - experiment (inc torque), sq - experiment (dec torque)')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated n times.
n_color_repeat = 2;
C = get(gca,'ColorOrder');
magenta = [1 0 1];
black = [0 0 0];
green = [0 1 0];
C = [C; magenta];%; black; green];
% C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all experimental datapoints. different color for each dataset.
markers = {'o','sq'};
for i=1:length(DATA_EXP)
    x = [DATA_EXP(i).data.MB_speed];
    scatter(x, [DATA_EXP(i).data.Tgk_reg], 30, markers{i}, 'DisplayName','Tgk_reg (TC5)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet_far], 30, markers{i}, 'DisplayName','Tgk_inlet_far (TC7)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet_pipe_1], 30, markers{i}, 'DisplayName','Tgk_inlet_pipe_1 (TC8)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet_pipe_2], 30, markers{i}, 'DisplayName','Tgk_inlet_pipe_2 (TC6)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet], 30, markers{i}, 'DisplayName','Tgk_inlet (avg)')
    scatter(x, [DATA_EXP(i).data.Tgk_exp], 30, markers{i}, 'DisplayName','Tgk_exp (avg)')
    scatter(x, [DATA_EXP(i).data.TgPP], 30, markers{i}, 'DisplayName','TgPP (TC9)')
    scatter(x, [DATA_EXP(i).data.TgCC_exp], 30, markers{i}, 'DisplayName','TgCC_exp (TC10)')
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    x = [DATA_MOD(i).data.speedRPM];
    % plot mean of each setpoint
    scatter(x, mean([DATA_MOD(i).data.Tgk_reg]), 40, C(1,:), 'x', 'DisplayName','Tgk_reg')
    scatter(x, mean([DATA_MOD(i).data.Tgk_inlet]), 40, C(5,:), 'x','DisplayName','Tgk_inlet') 
    scatter(x, mean([DATA_MOD(i).data.Tgk_center]), 40, C(6,:), 'x','DisplayName','Tgk_center') 
    scatter(x, mean([DATA_MOD(i).data.TgPP]), 40, C(7,:), 'x','DisplayName','TgPP') 
    scatter(x, mean([DATA_MOD(i).data.TgPP_PPtop_test]), 40, C(7,:), '+','DisplayName','TgPP_PPtop_test') 
    scatter(x, mean([DATA_MOD(i).data.TgCC]), 40, C(8,:), 'x','DisplayName','TgCC') 
end

%% PV comparison %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Avg and max deviation in pressure between exp and mod, vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = "";
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Pressure Relative Deviation [%]')
title('Deviation in pressure')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated n times.
n_color_repeat = 2;
C = get(gca,'ColorOrder');
C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all model datapoints. different color for each dataset.
for i=1:size(p_dev_mean, 1)
    scatter([DATA_MOD(i).data.speedRPM], p_dev_mean{i}*100, 40, 'x')
    scatter([DATA_MOD(i).data.speedRPM], p_dev_max{i}*100, 40, '+')
    legname = DATA_MOD(i).name;
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr(2*(i-1)+1) = "Mean: " + legname;
    legstr(2*(i-1)+2) = "Max: " + legname;
end
legend(legstr, 'Interpreter', 'none')


%% PV overlap between exp and mod, vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = {};
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('PV overlap ratio [%]')
title('PV overlap')
nicefigure(figure_purpose);

% plot all model datapoints. different color for each dataset.
for i=1:size(PV_overlap_ratio, 1)
    scatter([DATA_MOD(i).data.speedRPM], PV_overlap_ratio{i}*100, 40, colors{i},'x')
    legname = DATA_MOD(i).name;
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{i} = legname;

end
% legend(legstr, 'Interpreter', 'none')
l=legend('200 kPa','350 kPa','400 kPa','450 kPa', 'Location','northoutside');
l.ItemTokenSize(1) = 10;
% scatter([RD_DATA.MB_speed], PV_overlap_ratio*100, 30, [RD_DATA.pmean]./1000,'x')

%% Pressure Drop vs crank angle %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% p_DCH and p_DM vs angle (EXP), several datapoints
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Crank angle [\circ]')
ylabel('Pressure vs mean [Pa]')
title('p-DCH (Expansion space) and p-DM (Compression space)')
nicefigure(figure_purpose);
plots_i = 1;

colors = {'r','b'};
markers = {'-','--'};
% markers = repelem(markers,2);
angles = 1:360;
datasets = 2;
datapoints = [1,9];

% plot all experimental datapoints. different color for each dataset.
for i = 1:length(datasets)
    for d = 1:length(datapoints)
        legname = ['Exp, ' num2str( DATA_EXP(datasets(i)).data(datapoints(d)).pmean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_EXP(datasets(i)).data(datapoints(d)).MB_speed) ) 'rpm, p_DCH'];
        p = plot(angles, [DATA_EXP(datasets(i)).data(datapoints(d)).p_DCH_avg]-DATA_EXP(datasets(i)).data(datapoints(d)).pmean, [colors{d} markers{1}], 'DisplayName',legname);
        
        legname = ['Exp, ' num2str( DATA_EXP(datasets(i)).data(datapoints(d)).pmean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_EXP(datasets(i)).data(datapoints(d)).MB_speed) ) 'rpm, p_DM'];
        p = plot(angles, [DATA_EXP(datasets(i)).data(datapoints(d)).p_DM_avg]-DATA_EXP(datasets(i)).data(datapoints(d)).pmean,  [colors{d} markers{2}], 'DisplayName',legname);
    end
end
    %     if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
    text(10,max([DATA_EXP(datasets(i)).data(datapoints(d)).p_DCH_avg]), "Dataset "+datasets(i)+newline+"Datapoint "+datapoints(d))
% plot all model datapoints. different color for each dataset.
%     legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
%     if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
%     p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, [DATA_EXP(i).data.pmean]./1000, 'x', 'DisplayName',legname);
%     if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  

legend('Interpreter', 'none')
colormap(jet(10))

%% p_DCH and p_DM vs angle (EXP and MOD), one datapoint
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Crank angle [\circ]')
ylabel('Pressure vs mean [Pa]')
title('p-DCH (Expansion space) and p-DM (Compression space)')
nicefigure(figure_purpose);
plots_i = 1;

colors = {'b','r'};
markers = {'-','--'};
% markers = repelem(markers,2);
angles = 1:360;
anglesMOD = linspace(1,360,199);

datasets = 3;
datapoints = 1;
% datapoints = length(DATA_EXP(datasets).data);

% plot all experimental datapoints. different color for each dataset.
for i = 1:length(datasets)
    for d = 1:length(datapoints)
        legname = ['Exp, ' num2str( DATA_EXP(datasets(i)).data(datapoints(d)).pmean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_EXP(datasets(i)).data(datapoints(d)).MB_speed) ) 'rpm, p_DCH'];
        p = plot(angles, [DATA_EXP(datasets(i)).data(datapoints(d)).p_DCH_avg]-DATA_EXP(datasets(i)).data(datapoints(d)).pmean, [colors{1} markers{1}], 'DisplayName',legname);        
        legname = ['Exp, ' num2str( DATA_EXP(datasets(i)).data(datapoints(d)).pmean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_EXP(datasets(i)).data(datapoints(d)).MB_speed) ) 'rpm, p_DM'];
        p = plot(angles, [DATA_EXP(datasets(i)).data(datapoints(d)).p_DM_avg]-DATA_EXP(datasets(i)).data(datapoints(d)).pmean,  [colors{2} markers{1}], 'DisplayName',legname);
    
        legname = ['Mod, ' num2str( DATA_MOD(datasets(i)).data(datapoints(d)).p_mean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_MOD(datasets(i)).data(datapoints(d)).speedRPM) ) 'rpm, p_Exp'];
        p = plot(anglesMOD, circshift([DATA_MOD(datasets(i)).data(datapoints(d)).PV_Exp.p]-DATA_MOD(datasets(i)).data(datapoints(d)).p_mean, 100),  [colors{1} markers{2}], 'DisplayName',legname);
        legname = ['Mod, ' num2str( DATA_MOD(datasets(i)).data(datapoints(d)).p_mean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_MOD(datasets(i)).data(datapoints(d)).speedRPM) ) 'rpm, p_Com'];
        p = plot(anglesMOD, circshift([DATA_MOD(datasets(i)).data(datapoints(d)).PV_Com.p]-DATA_MOD(datasets(i)).data(datapoints(d)).p_mean, 100),  [colors{2} markers{2}], 'DisplayName',legname);

    end
end
%     text(10,max([DATA_EXP(datasets(i)).data(datapoints(d)).p_DCH_avg]), "Dataset "+datasets(i)+newline+"Datapoint "+datapoints(d))
legend('Interpreter','none', 'Location','south')
xlim([0,360])


%% delta_P vs crank (EXP and MOD), one dataset
figure(fig_count);
fig_count = fig_count+1;
hold on
%%%%%%%%%%%%%%%%%%%%%%%%%
units = 'abs';%'abs';
exp_smoothing_interval = 20; %interval size for moving mean on exp data
%%%%%%%%%%%%%%%%%%%%%%%%%
xlabel('Crank position')
switch units
    case 'abs'
        ylabel('Pressure Drop [Pa]')
    case 'rel'
        ylabel('Pressure Drop / P-mean [%]')
end
title('delta-P (Pressure drop): P-Exp - P-Com. Solid = exp, Dashed = model.')
nicefigure(figure_purpose);
plots_i = 1;
clear plots
angles = linspace(0,360,360);
anglesMOD = linspace(0,360,199);

datasets = 3;
% datapoints = 1;
datapoints = 1:length(DATA_EXP(datasets).data);

C = get(gca,'ColorOrder');
magenta = [1 0 1];
black = [0 0 0];
green = [0 1 0];
C = [C; black; green];
C = C(1:length(datapoints),:); % to get as many colors as there are plots.
C = repelem(C, 2, 1);
set(gca,'ColorOrder',C);
markers = {'-','--'};
% plot all experimental datapoints. different color for each dataset.
for i = 1:length(datasets)
    for d = 1:length(datapoints)
        legname = [num2str( DATA_EXP(datasets(i)).data(datapoints(d)).pmean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_EXP(datasets(i)).data(datapoints(d)).MB_speed) ) 'rpm'];
        dP_exp = [DATA_EXP(datasets(i)).data(datapoints(d)).p_DCH_avg]-[DATA_EXP(datasets(i)).data(datapoints(d)).p_DM_avg];
        % extend data at start and end of vector so that movmean has full window of data around each point
        dP_exp = [dP_exp(end+1-exp_smoothing_interval/2 : end); dP_exp; dP_exp(1:exp_smoothing_interval/2)];
        dP_exp = movmean(dP_exp,exp_smoothing_interval); %smoothing the curves
        dP_exp = dP_exp(1+exp_smoothing_interval/2 : end-exp_smoothing_interval/2); % return data to original length
        dP_mod = circshift([DATA_MOD(datasets(i)).data(datapoints(d)).PV_Exp.p]-[DATA_MOD(datasets(i)).data(datapoints(d)).PV_Com.p], 100);
        if strcmp(units,'rel')
            dP_exp = dP_exp ./DATA_EXP(datasets(i)).data(datapoints(d)).pmean *100;
            dP_mod = dP_mod ./DATA_MOD(datasets(i)).data(datapoints(d)).p_mean *100;
        end
        p = plot(angles, dP_exp, [markers{1}], 'DisplayName',legname);
        plots(plots_i) = p;
        plots_i = plots_i+1;
        %         legname = ['Mod, ' num2str( DATA_MOD(datasets(i)).data(datapoints(d)).p_mean_setpoint/1000 ) 'kPa, ' num2str( round(DATA_MOD(datasets(i)).data(datapoints(d)).speedRPM) ) 'rpm'];
        plot(anglesMOD, dP_mod,  [markers{2}], 'DisplayName',legname);
    end
end
legend(plots, 'Interpreter','none')
xlim([0,360])
myXticks = 0:90:360;
xticks(myXticks)
xticklabels({'Max Volume','Heating begins','Min Volume','Cooling begins','Max Volume'})


%% Pressure drop vs Speed/Re %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% pre-calcs
exp_smoothing_interval = 20; %interval size for moving mean on exp data
% Requires DATA_EXP and DATA_MOD to have same number of datasets with equal
% number of datatpoints
for i = 1:length(DATA_EXP)
    for d = 1:length(DATA_EXP(i).data)
        dP_exp = [DATA_EXP(i).data(d).p_DCH_avg]-[DATA_EXP(i).data(d).p_DM_avg];
                % extend data at start and end of vector so that movmean has full window of data around each point
        dP_exp = [dP_exp(end+1-exp_smoothing_interval/2 : end); dP_exp; dP_exp(1:exp_smoothing_interval/2)];
        dP_exp = movmean(dP_exp,exp_smoothing_interval); %smoothing the exp data
        dP_exp = dP_exp(1+exp_smoothing_interval/2 : end-exp_smoothing_interval/2); % return data to original length
        dP_mean_positive_exp{i}(d) = mean(dP_exp(dP_exp>0));
        dP_mean_negative_exp{i}(d) = mean(dP_exp(dP_exp<0));
        dP_max_exp{i}(d) = max(dP_exp);
        dP_min_exp{i}(d) = min(dP_exp);
        % 'close' the pressure curve so that zero crossing at first or last element will be found
        dP_zeros_exp{i,d} = find(diff(sign([dP_exp; dP_exp(1)])));
%                 [dP_max_exp{i}(d), dP_max_angle_exp{i}(d)] = max(dP_exp);
%         [dP_min_exp{i}(d), dP_min_angle_exp{i}(d)] = min(dP_exp);

        dP_mod = circshift([DATA_MOD(i).data(d).PV_Exp.p]-[DATA_MOD(i).data(d).PV_Com.p], 100);
        dP_mean_positive_mod{i}(d) = mean(dP_mod(dP_mod>0));
        dP_mean_negative_mod{i}(d) = mean(dP_mod(dP_mod<0));
        dP_max_mod{i}(d) = max(dP_mod);
        dP_min_mod{i}(d) = min(dP_mod);
        dP_zeros_mod{i,d} = find(diff(sign([dP_mod; dP_mod(1)]))) /length(dP_mod)*length(dP_exp); % to degrees;
%         [dP_max_mod{i}(d), dP_max_angle_mod{i}(d)] = max(dP_mod);
%         [dP_min_mod{i}(d), ind] = min(dP_mod);
%         dP_min_angle_mod{i}(d) = ind/length(dP_mod)*360; % to degrees

    end
end

%% delta_P Maximum and Minimum vs Reynolds OR speed
figure(fig_count);
fig_count = fig_count+1;
hold on
%%%%%%%%%%%%%%
units = 'abs'; %'rel'
X_var = 'Re'; %'speed'
%%%%%%%%%%%%%%
switch units
    case 'abs'
        ylabel('Pressure Drop [Pa]')
    case 'rel'
        ylabel('Pressure Drop / P-mean [%]')
end
title('MAXIMUM delta-P (Pressure drop): P-Exp - P-Com.')
nicefigure(figure_purpose);
plots_i = 1;
clear plots

markers = {'o','sq','x','+'};
colors = {'k','b','g','r'};

switch X_var % determine data for X axis
    case 'Re'
        xlabel('Reynolds Number')
        ENGINE_DATA = T2_ENGINE_DATA;
        for i=1:length(DATA_EXP)
            Tg_avg = mean([[DATA_EXP(i).data.Tgk_inlet]; [DATA_EXP(i).data.Tgh_inlet]]);
            % Re = rho * D_h * V / mu
            % rho = p/(RT)
            X{i} =  (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15)) .* ENGINE_DATA.cooler_D_h .* (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60 / ENGINE_DATA.cooler_A_cross) ./ Visc_air(Tg_avg);
        end
    case 'speed'
        xlabel('Speed [rpm]')
        for i=1:length(DATA_EXP)
            X{i} = [DATA_MOD(i).data.speedRPM];
        end
end

% plot all experimental datapoints. different color for each dataset.
for i = 1:length(DATA_EXP)   
    Y_plot = dP_max_exp{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_EXP(i).data.pmean] *100;
    end
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa, max'];
    p = scatter(X{i}, Y_plot, 30, colors{i}, markers{1}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
    
    Y_plot = -dP_min_exp{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_EXP(i).data.pmean] *100;
    end
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa, min'];
    p = scatter(X{i}, Y_plot, 30, colors{i}, markers{2}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
    
end
for i = 1:length(DATA_MOD)
    Y_plot = dP_max_mod{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_MOD(i).data.p_mean] *100;
    end
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa, max'];
    p = scatter(X{i}, Y_plot, 40, colors{i}, markers{3}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
    
    Y_plot = -dP_min_mod{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_MOD(i).data.p_mean] *100;
    end
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa, min'];
    p = scatter(X{i}, Y_plot, 40, colors{i}, markers{4}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
end
legend(plots([1,2,7,8]), 'Interpreter','none')


%% delta_P Mean (positive and negative) vs Reynolds OR speed
figure(fig_count);
fig_count = fig_count+1;
hold on
%%%%%%%%%%%%%%
units = 'abs'; %'rel'
X_var = 'speed'; %'speed'
%%%%%%%%%%%%%%
switch units
    case 'abs'
        ylabel('Pressure Drop [Pa]')
    case 'rel'
        ylabel('Pressure Drop / P-mean [%]')
end
title('MEAN delta-P (Pressure drop): P-Exp - P-Com.')
nicefigure(figure_purpose);
plots_i = 1;
clear plots

markers = {'o','sq','x','+'};
colors = {'k','b','g','r'};

switch X_var
    case 'Re'
        xlabel('Reynolds Number')
        ENGINE_DATA = T2_ENGINE_DATA;
        for i=1:length(DATA_EXP)
            Tg_avg = mean([[DATA_EXP(i).data.Tgk_inlet]; [DATA_EXP(i).data.Tgh_inlet]]);
            % Re = rho * D_h * V / mu
            % rho = p/(RT)
            X{i} =  (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15)) .* ENGINE_DATA.cooler_D_h .* (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60 / ENGINE_DATA.cooler_A_cross) ./ Visc_air(Tg_avg);
        end
    case 'speed'
        xlabel('Speed [rpm]')
        for i=1:length(DATA_EXP)
            X{i} = [DATA_MOD(i).data.speedRPM];
        end
end

% plot all experimental datapoints. different color for each dataset.
for i = 1:length(DATA_EXP)   
    Y_plot = dP_mean_positive_exp{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_EXP(i).data.pmean] *100;
    end
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa, pos'];
    p = scatter(X{i}, Y_plot, 30, colors{i}, markers{1}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
    
    Y_plot = -dP_mean_negative_exp{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_EXP(i).data.pmean] *100;
    end
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa, neg'];
    p = scatter(X{i}, Y_plot, 30, colors{i}, markers{2}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
    
end
for i = 1:length(DATA_MOD)
    Y_plot = dP_mean_positive_mod{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_MOD(i).data.p_mean] *100;
    end
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa, pos'];
    p = scatter(X{i}, Y_plot, 40, colors{i}, markers{3}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
    
    Y_plot = -dP_mean_negative_mod{i};
    if strcmp(units,'rel')
        Y_plot = Y_plot ./[DATA_MOD(i).data.p_mean] *100;
    end
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa, neg'];
    p = scatter(X{i}, Y_plot, 40, colors{i}, markers{4}, 'DisplayName',legname);
    plots(plots_i) = p;
    plots_i = plots_i+1;
end
legend(plots([1,3,5]), 'Interpreter','none')


%% Crank positions with delta_P = 0, vs Reynolds OR speed
figure(fig_count);
fig_count = fig_count+1;
hold on
%%%%%%%%%%%%%%
X_var = 'Re'; %'speed'
%%%%%%%%%%%%%%
ylabel('Crank position')
title('Crank positions with Zero Pressure Drop')
nicefigure(figure_purpose);
plots_i = 1;
clear plots

markers = {'o','sq','x','+'};
colors = {'k','b','g','r'};

switch X_var
    case 'Re'
        xlabel('Reynolds Number')
        ENGINE_DATA = T2_ENGINE_DATA;
        for i=1:length(DATA_EXP)
            Tg_avg = mean([[DATA_EXP(i).data.Tgk_inlet]; [DATA_EXP(i).data.Tgh_inlet]]);
            % Re = rho * D_h * V / mu
            % rho = p/(RT)
            X{i} =  (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15)) .* ENGINE_DATA.cooler_D_h .* (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60 / ENGINE_DATA.cooler_A_cross) ./ Visc_air(Tg_avg);
        end
    case 'speed'
        xlabel('Speed [rpm]')
        for i=1:length(DATA_EXP)
            X{i} = [DATA_MOD(i).data.speedRPM];
        end
end

for i = 1:length(DATA_EXP)
    for d = 1:length(DATA_EXP(i).data)
        Y_plot = dP_zeros_exp{i,d};
        X_plot = repelem(X{i}(d), length(Y_plot));
        legname = ['Exp, ' num2str( DATA_EXP(i).data(d).pmean_setpoint/1000 ) 'kPa'];
        p = scatter(X_plot, Y_plot, 30, colors{i}, markers{1}, 'DisplayName',legname);
        if d == 1
            plots(plots_i) = p;
            plots_i = plots_i+1;
        end
    end
end
for i = 1:length(DATA_MOD)
    for d = 1:length(DATA_MOD(i).data)
        Y_plot = dP_zeros_mod{i,d};
        X_plot = repelem(X{i}(d), length(Y_plot));
        legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
        p = scatter(X_plot, Y_plot, 40, colors{i}, markers{3}, 'DisplayName',legname);
        if d == 1
            plots(plots_i) = p;
            plots_i = plots_i+1;
        end
    end
end
ylim([0,360])
yticks(0:90:360)
yticklabels({'Max Volume','Heating begins','Min Volume','Cooling begins','Max Volume'})
yline(90); yline(270);
legend(plots, 'Interpreter','none')
