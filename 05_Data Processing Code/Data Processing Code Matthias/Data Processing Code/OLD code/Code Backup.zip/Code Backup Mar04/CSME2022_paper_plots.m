%% Indicated Work vs speed, pressure color coded, with colors in legend
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Work [J]')
title('Indicated Work')
nicefigure(figure_purpose);
plots_i = 1;

colors = {'k','b','g','r','y'};
markers = {'x'};
markers = repelem(markers,3);
% colors = {'k','b','g','r'};
% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp], 30, colors{i}, 'o', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, colors{i}, markers{1}, 'DisplayName',legname);
    if i==1 || i==4; plots(plots_i) = p; plots_i = plots_i+1; end  
end
%  axis tight
l=legend;
% l=legend('Exp','Mod old','Mod new','Mod new, HX insulated','Mod new, HX insulated, 1node', 'HX insulated, equal thickness')
l.ItemTokenSize(1) = 10;


%% To Add p_atmosphere to processed 'RD' files
[file,path]=uigetfile('G:\Shared drives\NOBES_GROUP\MSPM\[MATLAB_WORKING_FOLDER]\Data Processing Code\06_Post Processing_Experimental\[Experimental Data]');
load(fullfile(path,file));
for i=1:length(RD_DATA)
    RD_DATA(i).p_atm=93790;
end

save(fullfile(path,file),'RD_DATA','-v7.3')

%% Ratio of Indicated Work vs speed, pressure color coded, with colors in legend
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Ind. Work Ratio Model/Experiment [%]')
title('Indicated Work Ratio')
nicefigure(figure_purpose);
plots_i = 1;

colors = {'k','b','g','r'};
colors = repmat(colors,1,2);
markers = {'x','+'};
markers = repelem(markers,4);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = [num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    
    range = 1:min([length(DATA_EXP(i).data), length(DATA_MOD(i).data)]);
    Wind_ratio = [DATA_MOD(i).data(range).Wind] ./ [DATA_EXP(i).data(range).Wind_exp];
    p = scatter([DATA_EXP(i).data(range).MB_speed], Wind_ratio*100, 40, colors{i}, markers{i}, 'DisplayName',legname);
    if i==1 || i==5; plots(plots_i) = p; plots_i = plots_i+1; end
end
% l=legend('Mod old','Mod new','Mod new, HX insulated')
% yline(100)
% legend(plots,{'FinConn(old)','FinEnh(new)'})
legend

%% Ratio of Indicated Work vs Reynolds number, pressure color coded, with colors in legend
% calculate HX Reynolds numbers (mean speed, mean gas temp)
ENGINE_DATA = T2_ENGINE_DATA;
for i=1:length(DATA_EXP)
    Tg_avg = mean([[DATA_EXP(i).data.Tgk_inlet]; [DATA_EXP(i).data.Tgh_inlet]]);

% Re = rho * D_h * V / mu
    % rho = p/(RT)
    Reynolds_HX{i} =  (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15)) .* ENGINE_DATA.cooler_D_h .* (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60 / ENGINE_DATA.cooler_A_cross) ./ Visc_air(Tg_avg);
    Massflow_HX{i} = (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60) .* (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15));
end

figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Reynolds Number (HX Avg)')
ylabel('Ind. Work Ratio Model/Experiment [%]')
title('Indicated Work')
nicefigure(figure_purpose);
plots_i = 1;

% colors = {'k','b','g','r'};
% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    
    range = 1:min([length(DATA_EXP(i).data), length(DATA_MOD(i).data)]);
    Wind_ratio = [DATA_MOD(i).data(range).Wind] ./ [DATA_EXP(i).data(range).Wind_exp];
    p = scatter(Reynolds_HX{i}(range), Wind_ratio*100, 40, colors{i}, markers{i}, 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end

yline(100);
l=legend
% l=legend('Exp','Mod old','Mod new','Mod new, HX insulated','Mod new, HX insulated, 1node')
l.ItemTokenSize(1) = 10;


% % Looks same when plotted over Mass flow rate, since (Re = const * mdot) if
% % mu=const.
% figure(fig_count);
% fig_count = fig_count+1;
% hold on
% leg_chars = 30;
% xlabel('Avg. Mass Flow Rate [kg/s]')
% ylabel('Ind. Work Ratio Model/Experiment [%]')
% title('Indicated Work')
% nicefigure(figure_purpose);
% plots_i = 1;
% 
% colors = {'k','b','g','r'};
% % plot all experimental datapoints. different color for each dataset.
% for i=1:length(DATA_EXP)
%     legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
%     if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
%     
%     Wind_ratio = [DATA_MOD(i).data.Wind] ./ [DATA_EXP(i).data.Wind_exp];
%     p = scatter(Massflow_HX{i}, Wind_ratio*100, 40, colors{i}, 'x', 'DisplayName',legname);
%     if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
% end
% yline(100);

%% Eff vs speed, pressure color coded, with colors in legend
figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Efficiency [%]')
title('Efficiency (indicated)')
nicefigure(figure_purpose);
plots_i = 1;

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.efficiency_ind]*100, 30, colors{i}, 'o', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end

% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.efficiency_ind]*100, 40, colors{i}, markers{i}, 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

% legend('Interpreter', 'none')
% colormap(jet(10))
% axis tight
l=legend(plots);
l.ItemTokenSize(1) = 10;

%% New Eff Plots, not in CSME paper %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Eff vs Reynolds Number, pressure color coded, with colors in legend
% calculate HX Reynolds numbers (mean speed, mean gas temp)
ENGINE_DATA = T2_ENGINE_DATA;
for i=1:length(DATA_EXP)
    Tg_avg = mean([[DATA_EXP(i).data.Tgk_inlet]; [DATA_EXP(i).data.Tgh_inlet]]);

% Re = rho * D_h * V / mu
    % rho = p/(RT)
    Reynolds_HX{i} =  (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15)) .* ENGINE_DATA.cooler_D_h .* (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60 / ENGINE_DATA.cooler_A_cross) ./ Visc_air(Tg_avg);
    Massflow_HX{i} = (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60) .* (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15));
end

figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Reynolds Number (HX Avg)')
ylabel('Indicated Efficiency [%]')
title('Efficiency (indicated)')
nicefigure(figure_purpose);
plots_i = 1;

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter(Reynolds_HX{i}, [DATA_EXP(i).data.efficiency_ind]*100, 30, colors{i}, 'o', 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end
end

% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    legname = ['Mod, ' num2str( DATA_MOD(i).data(1).p_mean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    p = scatter(Reynolds_HX{i}, [DATA_MOD(i).data.efficiency_ind]*100, 40, colors{i}, markers{i}, 'DisplayName',legname);
    if i==1; plots(plots_i) = p; plots_i = plots_i+1; end  
end

% legend('Interpreter', 'none')
% colormap(jet(10))
% axis tight
l=legend(plots);
l.ItemTokenSize(1) = 10;


%% Ratio of Efficiency vs Reynolds Number, pressure color coded, with colors in legend
% calculate HX Reynolds numbers (mean speed, mean gas temp)
ENGINE_DATA = T2_ENGINE_DATA;
for i=1:length(DATA_EXP)
    Tg_avg = mean([[DATA_EXP(i).data.Tgk_inlet]; [DATA_EXP(i).data.Tgh_inlet]]);

% Re = rho * D_h * V / mu
    % rho = p/(RT)
    Reynolds_HX{i} =  (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15)) .* ENGINE_DATA.cooler_D_h .* (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60 / ENGINE_DATA.cooler_A_cross) ./ Visc_air(Tg_avg);
    Massflow_HX{i} = (ENGINE_DATA.Vswd * 2 * [DATA_EXP(i).data.MB_speed]/60) .* (([DATA_EXP(i).data.pmean]+[DATA_EXP(i).data.p_atm]) ./287 ./(Tg_avg+273.15));
end

figure(fig_count);
fig_count = fig_count+1;
hold on
leg_chars = 30;
xlabel('Reynolds Number (HX Avg)')
ylabel('Efficiency Ratio Model/Experiment [%]')
title('Efficiency (indicated)')
nicefigure(figure_purpose);
plots_i = 1;

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    legname = ['Exp, ' num2str( DATA_EXP(i).data(1).pmean_setpoint/1000 ) 'kPa'];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    
    range = 1:min([length(DATA_EXP(i).data), length(DATA_MOD(i).data)]);
    Eff_ratio = [DATA_MOD(i).data(range).efficiency_ind] ./ [DATA_EXP(i).data(range).efficiency_ind];
    p = scatter(Reynolds_HX{i}, Eff_ratio*100, 40, colors{i}, markers{i}, 'DisplayName',legname);
    if i==1 || i==5; plots(plots_i) = p; plots_i = plots_i+1; end
end

yline(100);
l=legend(plots,{'FinConn(old)','FinEnh(new)'})
 axis tight
l.ItemTokenSize(1) = 10;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% PV overlap between exp and mod, vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = {};
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('PV overlap ratio [%]')
title('PV overlap')
nicefigure(figure_purpose);

markers = {'x','+'};
markers = repelem(markers,3);

% plot all model datapoints. different color for each dataset.
for i=1:size(PV_overlap_ratio, 1)
    scatter([DATA_MOD(i).data.speedRPM], PV_overlap_ratio{i}*100, 40, colors{i},markers{1})
    legname = DATA_MOD(i).name;
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{i} = legname;

end
% legend(legstr, 'Interpreter', 'none')
l=legend('200 kPa','350 kPa','400 kPa','450 kPa', 'Location','northoutside');
l.ItemTokenSize(1) = 10;
% scatter([RD_DATA.MB_speed], PV_overlap_ratio*100, 30, [RD_DATA.pmean]./1000,'x')
