function nicefigure(purpose)

switch purpose
    
    case 'thesis'
        set(gca, 'FontName','Times New Roman','FontSize',12,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 4, 6.5, 4.5]);
        
    case 'paper'
        set(gca, 'FontName','Times New Roman','FontSize',10,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 4, 7.25/3, 3.5]);
        
    case 'presentation'
        set(gca, 'FontName','Times New Roman','FontSize',10,...
            'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1,...
            'XGrid','on','YGrid','on','GridColor',[0 0 0]);
        % [left bottom width height]
        set(gcf, 'Units','inches','Position',[9, 4, 4.75, 4]);
        
        
end
