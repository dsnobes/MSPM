%%
setpoint_name = 'p200 TH135 T0.5';

%% MODEL DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Gas temps of one datapoint
%hot
dp_index = 11;
figure
hold on
xlabel('Crank angle')
ylabel('Temp (\circC)')
legend('Interpreter', 'none')
x = linspace(0,360,199);
plot(x,MSPM_DATA(dp_index).Tge, 'DisplayName','Tge') 
plot(x,MSPM_DATA(dp_index).Tgh_inlet, 'DisplayName','Tgh_inlet')
plot(x,MSPM_DATA(dp_index).Tgh_center, 'DisplayName','Tgh_center')
plot(x,MSPM_DATA(dp_index).Tgh_reg, 'DisplayName','Tgh_reg')
plot(x,MSPM_DATA(dp_index).Tgh_reg_TopOfReg_test, 'DisplayName','Tgh_reg_TopOfReg_test')
plot(x,MSPM_DATA(dp_index).Tgr_center, 'DisplayName','Tgr_center')
yline(MSPM_DATA(dp_index).Tgr_log, 'DisplayName','Tgr_log')
xline(0,'-',{'Expansion begins','Gas moving cold->hot'}, 'DisplayName','')
xline(90,'-',{'All Gas on hot side'})
xline(180,'-',{'Compression begins','Gas moving hot->cold'})
xline(270,'-',{'All Gas on cold side'})

%cold
figure
hold on
xlabel('Crank angle')
ylabel('Temp (\circC)')
legend('Interpreter', 'none')
plot(x,MSPM_DATA(dp_index).Tgk_reg, 'DisplayName','Tgk_reg')
plot(x,MSPM_DATA(dp_index).Tgk_center, 'DisplayName','Tgk_center')
plot(x,MSPM_DATA(dp_index).Tgk_inlet, 'DisplayName','Tgk_inlet')
plot(x,MSPM_DATA(dp_index).Tgc, 'x', 'DisplayName','Tgc')
plot(x,MSPM_DATA(dp_index).TgPP, 'DisplayName','TgPP')
plot(x,MSPM_DATA(dp_index).TgPP_PPtop_test, 'DisplayName','TgPP_PPtop_test')
plot(x,MSPM_DATA(dp_index).TgCC, 'DisplayName','TgCC')
xline(0,'-',{'Expansion begins','Gas moving cold->hot'}, 'DisplayName','')
xline(90,'-',{'All Gas on hot side'})
xline(180,'-',{'Compression begins','Gas moving hot->cold'})
xline(270,'-',{'All Gas on cold side'})



%% EXPERIMENT DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Speed
figure
plot(C_DATA.time_VC ./60, C_DATA.MB_speed_time)
title([setpoint_name ' - Speed'])

ylim([130,160])
% xlim([0,5500)
xlabel('Time[min]')
ylabel('Speed[rpm]')
grid on

%% Torque
figure
hold on
% mean_torque = movmean(C_DATA.torque_sensor, 50);
% plot(C_DATA.time_VC ./60, mean_torque)
mean_torque = movmean(C_DATA.torque_sensor, 100);
plot(C_DATA.time_VC ./60, mean_torque)
% mean_torque = movmean(C_DATA.torque_sensor, 200);
% plot(C_DATA.time_VC ./60, mean_torque)
% legend('Mov Mean window size 50','Mov Mean window size 100','Mov Mean window size 200')

title([setpoint_name ' - Measured Torque'])

%   ylim([0.3,0.7])
% xlim([0,5500)
xlabel('Time[min]')
ylabel('Measured Torque[Nm]')
grid on

%% RTDs heater
figure
plot(C_DATA.time_RTD ./60, C_DATA.RTD_2,  C_DATA.time_RTD ./60, C_DATA.RTD_3)
legend('RTD Heater In','RTD Heater Out')
title([setpoint_name ' - RTDs Heater'])

% ylim([150,180])
% xlim([0,5500)
xlabel('Time[min]')
ylabel('Temp[\circC]')
grid on

%% RTDs cooler
figure
plot(C_DATA.time_RTD ./60, C_DATA.RTD_4,  C_DATA.time_RTD ./60, C_DATA.RTD_5)
legend('RTD Cooler In','RTD Cooler Out')
title([setpoint_name ' - RTDs Cooler'])

% ylim([150,180])
% xlim([0,5500)
xlabel('Time[min]')
ylabel('Temp[\circC]')
grid on

%% TCs hot
figure
plot(C_DATA.time_TC ./60, C_DATA.TC_0,  C_DATA.time_TC ./60, C_DATA.TC_1, C_DATA.time_TC ./60, C_DATA.TC_2, C_DATA.time_TC ./60, C_DATA.TC_3, C_DATA.time_TC ./60, C_DATA.TC_4)
legend( 'Expansion Space', 'Heater/Expansion Space Interface, Bypass Side', 'Heater/Expansion Space Interface, Connecting Pipe Side', 'Regen/Heater Interface, Bypass Side', 'Regen/Heater Interface, Connecting Pipe Side')
title([setpoint_name ' - TC Hot Side Gas Temperatures'])
 ylim([90,100])
% xlim([0,5500)
xlabel('Time[min]')
ylabel('Temp[\circC]')
grid on

%% TCs cold
figure
plot(C_DATA.time_TC ./60, C_DATA.TC_5,  C_DATA.time_TC ./60, C_DATA.TC_6, C_DATA.time_TC ./60, C_DATA.TC_7, C_DATA.time_TC ./60, C_DATA.TC_8, C_DATA.time_TC ./60, C_DATA.TC_9)
legend( 'Cooler/Regenerator Interface, Bypass Side','Cooler/Regenerator Interface, Connecting Pipe Side', 'Compression Space/Cooler Interface, Bypass Side', 'Compression Space/Cooler Interface, Connecting Pipe Side', 'Power Cylinder')
%     TC_6 --> Cooler/Regenerator Interface, Connecting Pipe Side
%     TC_7 --> Compression Space/Cooler Interface, Bypass Side
%     TC_8 --> Compression Space/Cooler Interface, Connecting Pipe Side
%     TC_9 --> Power Cylinder
title([setpoint_name ' - TC Cold Side Gas Temperatures'])
  ylim([23,30])
% xlim([0,5500)
xlabel('Time[min]')
ylabel('Temp[\circC]')
grid on