%% SECTION 1: Data import %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RUN THIS SECTION FIRST. No inputs required.
 clear, close all
[DATA_EXP, DATA_MOD] = DataPlot_import; % calls subfunction
fig_count = 1; % figure counter
figure_purpose = 'presentation';


%% SECTION 2: PV curve comparison %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SET INPUTS BELOW BEFORE RUNNING
% Run this section if you want to compute and plot the PV diagram
% comparison parameters for ONE experimental and one or several model datasets.

% INPUTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Whether to plot the PVs for each data point.
plotPVs = 0;

% SPECIFY the indices (in DATA_EXP and DATA_MOD) of the datasets that
% should be used for comparing PV shapes. Must have same order of datapoints.
% Only ONE experimental dataset, but can select SEVERAL model datasets.
% Plots only work for ONE model dataset.
iPV_exp = 1; % MUST BE ONE ONLY (scalar)

% iPV_mod = 2; % CAN BE SEVERAL (VECTOR)
iPV_mod = 1:length(DATA_MOD); % CAN BE SEVERAL (VECTOR)

% END INPUTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Outputs: p_dev_max, p_dev_mean, PV_overlap_ratio
% Plots:
% (1) raw PV curves
% (2) Volume over crank angle, incl max volume deviation
% (3) Overlaid PV curves with overlap curve and percentage
[p_dev_max, p_dev_mean, PV_overlap_ratio] = DataPlot_PVcompare(plotPVs,figure_purpose,iPV_exp,iPV_mod, DATA_EXP,DATA_MOD);




%% SECTION 3: PLOTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Each section here has one plot. Desciption in the section header.


%% New Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The following plots make a scatter plots with a different color for each
% dataset. Experimental data is plotted as 'o', model data as 'x'.

%% Indicated Work vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = {};
leg_chars = 30;
xlabel('Speed [rpm]')
ylabel('Indicated Work [J]')
title('Indicated Work')
nicefigure(figure_purpose);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    % plot([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp])%, 30, [DATA_EXP(i).data.pmean]./1000)%,'o')
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp], 30, 'o')
    legname = ['Exp: ' DATA_EXP(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{i} =  legname;
    % scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.Wind_exp], 30, [DATA_EXP(i).data.pmean]./1000)%,'o')
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    %     scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 30, [DATA_MOD(i).data.p_mean]./1000)%,'x')
    scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, 'x')
    legname = ['Mod: ' DATA_MOD(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{length(DATA_EXP)+i} =  legname;
    
    %     plot([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind])%, 30, [DATA_MOD(i).data.p_mean]./1000)%,'x')
end
legend(legstr, 'Interpreter', 'none')


%% P shaft vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = {};
leg_chars = 25;
xlabel('Speed [rpm]')
ylabel('Shaft Power [W]')
title('Shaft Power')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated once.
n_color_repeat = 2;
C = get(gca,'ColorOrder');
C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all experimental datapoints. different color for each dataset.
for i=1:length(DATA_EXP)
    
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.P_shaft_exp], 30, 'o')
    scatter([DATA_EXP(i).data.MB_speed], [DATA_EXP(i).data.P_shaft_exp_tsensor], 40, 'x')
    legname = ['Exp: ' DATA_EXP(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
%     legstr{i} =  legname;
    legstr{2*(i-1)+1} = "(T setpoint) " + legname;
    legstr{2*(i-1)+2} = "(T measured) " + legname;

end
% plot all model datapoints. different color for each dataset.
% for i=1:length(DATA_MOD)
%     %     scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 30, [DATA_MOD(i).data.p_mean]./1000)%,'x')
%     scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind], 40, 'x')
%     legname = ['Mod: ' DATA_MOD(i).name];
%     if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
%     legstr{length(DATA_EXP)+i} =  legname;
%     
%     %     plot([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.Wind])%, 30, [DATA_MOD(i).data.p_mean]./1000)%,'x')
% end
legend(legstr, 'Interpreter', 'none')



%% Eff vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = {};
leg_chars = 40;
xlabel('Speed [rpm]')
ylabel('Indicated Efficiency [%]')
title('Efficiency (indicated)')
nicefigure(figure_purpose);

for i=1:length(DATA_EXP)
    % MB_speed in rpm
    eff_ind = [DATA_EXP(i).data.Wind_exp].*[DATA_EXP(i).data.MB_speed]./60 ./([DATA_EXP(i).data.Qdot_heater_exp]+[DATA_EXP(i).data.Qdot_DCH_exp]) *100; % [%]
    scatter([DATA_EXP(i).data.MB_speed], eff_ind, 30, 'o')
    legname = ['Exp: ' DATA_EXP(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{i} =  legname;
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    scatter([DATA_MOD(i).data.speedRPM], [DATA_MOD(i).data.efficiency_ind]*100, 40, 'x')
    legname = ['Mod: ' DATA_MOD(i).name];
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{length(DATA_EXP)+i} =  legname;
end
legend(legstr, 'Interpreter', 'none')


%% Gas Temperatures (Avg) vs speed

% Hot Side %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(fig_count);
fig_count = fig_count+1;
hold on
xlabel('Speed [rpm]')
ylabel('Gas Temperature [\circC]')
legend('Interpreter', 'none')
title('Gas Temperatures (TC), hot side. x - model, o - experiment (inc torque), sq - experiment (dec torque)')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated once.
n_color_repeat = 2;
C = get(gca,'ColorOrder');
magenta = [1 0 1];
black = [0 0 0];
green = [0 1 0];
C = [C; magenta; black; green];
% C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all experimental datapoints. different color for each dataset.
markers = {'o','sq'};
for i=1:length(DATA_EXP)
    x = [DATA_EXP(i).data.MB_speed];
    scatter(x, [DATA_EXP(i).data.Tge_exp], 30, markers{i}, 'DisplayName','Tge_exp (TC0)')
    scatter(x, [DATA_EXP(i).data.Tgh_inlet_far], 30, markers{i}, 'DisplayName','Tgh_inlet_far (TC1)')
    scatter(x, [DATA_EXP(i).data.Tgh_inlet_pipe], 30, markers{i}, 'DisplayName','Tgh_inlet_pipe (TC2)')
    scatter(x, [DATA_EXP(i).data.Tgh_inlet], 30, markers{i}, 'DisplayName','Tgh_inlet (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_reg_far], 30, markers{i}, 'DisplayName','Tgh_reg_far (TC3)')
    scatter(x, [DATA_EXP(i).data.Tgh_reg_pipe], 30, markers{i}, 'DisplayName','Tgh_reg_pipe (TC4)')
    scatter(x, [DATA_EXP(i).data.Tgh_reg], 30, markers{i}, 'DisplayName','Tgh_reg (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_exp_far], 30, markers{i}, 'DisplayName','Tgh_exp_far (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_exp_pipe], 30, markers{i}, 'DisplayName','Tgh_exp_pipe (avg)')
    scatter(x, [DATA_EXP(i).data.Tgh_exp], 30, markers{i}, 'DisplayName','Tgh_exp (avg)')
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    x = [DATA_MOD(i).data.speedRPM];
    % plot mean of each setpoint
    scatter(x, mean([DATA_MOD(i).data.Tge]), 40, C(1,:), 'x', 'DisplayName','Tge')
    scatter(x, mean([DATA_MOD(i).data.Tgh_inlet]), 40, C(4,:), 'x','DisplayName','Tgh_inlet') 
    scatter(x, mean([DATA_MOD(i).data.Tgh_reg]), 40, C(7,:), 'x','DisplayName','Tgh_reg') 
    scatter(x, mean([DATA_MOD(i).data.Tgh_reg_TopOfReg_test]), 40, C(7,:), '+','DisplayName','Tgh_reg_TopOfReg_test') 
    scatter(x, mean([DATA_MOD(i).data.Tgh_center]), 40, C(10,:), 'x','DisplayName','Tgh_center') 
end

% regenerator %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(fig_count);
fig_count = fig_count+1;
hold on
xlabel('Speed [rpm]')
ylabel('Gas Temperature [\circC]')
legend('Interpreter', 'none')
title('Gas Temperatures (TC), Regenerator. x - model, o - experiment (inc torque), sq - experiment (dec torque)')
nicefigure(figure_purpose);

markers = {'o','sq'};
for i=1:length(DATA_EXP)
    x = [DATA_EXP(i).data.MB_speed];
%     scatter(x, [DATA_EXP(i).data.Tgh_reg_far], 30, markers{i}, 'DisplayName','Tgh_reg_far')
%     scatter(x, [DATA_EXP(i).data.Tgh_reg_pipe], 30, markers{i}, 'DisplayName','Tgh_reg_pipe')
%     scatter(x, [DATA_EXP(i).data.Tgh_reg], 30, markers{i}, 'DisplayName','Tgh_reg')
    scatter(x, [DATA_EXP(i).data.Tgr_exp], 30, markers{i}, 'DisplayName','Tgr_exp (log mean Tgh_reg, Tgk_reg)')
%     scatter(x, [DATA_EXP(i).data.Tgk_reg], 30, markers{i}, 'DisplayName','Tgk_reg')
end

for i=1:length(DATA_MOD)
    x = [DATA_MOD(i).data.speedRPM];
    scatter(x, mean([DATA_MOD(i).data.Tgr_center]), 40, 'x','DisplayName','Tgr_center') 
    scatter(x, [DATA_MOD(i).data.Tgr_log], 40, 'x','DisplayName','Tgr_log (log mean Tgh_reg, Tgk_reg)') 
end

% Cold Side %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(fig_count);
fig_count = fig_count+1;
hold on
xlabel('Speed [rpm]')
ylabel('Gas Temperature [\circC]')
legend('Interpreter', 'none')
title('Gas Temperatures (TC), cold side. x - model, o - experiment (inc torque), sq - experiment (dec torque)')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated once.
n_color_repeat = 2;
C = get(gca,'ColorOrder');
magenta = [1 0 1];
black = [0 0 0];
green = [0 1 0];
C = [C; magenta];%; black; green];
% C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all experimental datapoints. different color for each dataset.
markers = {'o','sq'};
for i=1:length(DATA_EXP)
    x = [DATA_EXP(i).data.MB_speed];
    scatter(x, [DATA_EXP(i).data.Tgk_reg], 30, markers{i}, 'DisplayName','Tgk_reg (TC5)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet_far], 30, markers{i}, 'DisplayName','Tgk_inlet_far (TC7)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet_pipe_1], 30, markers{i}, 'DisplayName','Tgk_inlet_pipe_1 (TC8)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet_pipe_2], 30, markers{i}, 'DisplayName','Tgk_inlet_pipe_2 (TC6)')
    scatter(x, [DATA_EXP(i).data.Tgk_inlet], 30, markers{i}, 'DisplayName','Tgk_inlet (avg)')
    scatter(x, [DATA_EXP(i).data.Tgk_exp], 30, markers{i}, 'DisplayName','Tgk_exp (avg)')
    scatter(x, [DATA_EXP(i).data.TgPP], 30, markers{i}, 'DisplayName','TgPP (TC9)')
    scatter(x, [DATA_EXP(i).data.TgCC_exp], 30, markers{i}, 'DisplayName','TgCC_exp (TC10)')
end
% plot all model datapoints. different color for each dataset.
for i=1:length(DATA_MOD)
    x = [DATA_MOD(i).data.speedRPM];
    % plot mean of each setpoint
    scatter(x, mean([DATA_MOD(i).data.Tgk_reg]), 40, C(1,:), 'x', 'DisplayName','Tgk_reg')
    scatter(x, mean([DATA_MOD(i).data.Tgk_inlet]), 40, C(5,:), 'x','DisplayName','Tgk_inlet') 
    scatter(x, mean([DATA_MOD(i).data.Tgk_center]), 40, C(6,:), 'x','DisplayName','Tgk_center') 
    scatter(x, mean([DATA_MOD(i).data.TgPP]), 40, C(7,:), 'x','DisplayName','TgPP') 
    scatter(x, mean([DATA_MOD(i).data.TgPP_PPtop_test]), 40, C(7,:), '+','DisplayName','TgPP_PPtop_test') 
    scatter(x, mean([DATA_MOD(i).data.TgCC]), 40, C(8,:), 'x','DisplayName','TgCC') 
end

%% Avg and max deviation in pressure between exp and mod, vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = "";
leg_chars = 25;
xlabel('Speed [rpm]')
ylabel('Pressure Relative Deviation [%]')
title('Deviation in pressure')
nicefigure(figure_purpose);

% Change plot color order so that each color is repeated once.
n_color_repeat = 2;
C = get(gca,'ColorOrder');
C = repelem(C, n_color_repeat, 1);
set(gca,'ColorOrder',C);

% plot all model datapoints. different color for each dataset.
for i=1:size(p_dev_mean, 1)
    scatter([DATA_MOD(i).data.speedRPM], p_dev_mean(i,:)*100, 40, 'x')
    scatter([DATA_MOD(i).data.speedRPM], p_dev_max(i,:)*100, 40, '+')
    legname = DATA_MOD(i).name;
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr(2*(i-1)+1) = "Mean: " + legname;
    legstr(2*(i-1)+2) = "Max: " + legname;
end
legend(legstr, 'Interpreter', 'none')


%% PV overlap between exp and mod, vs speed
figure(fig_count);
fig_count = fig_count+1;
hold on
legstr = {};
leg_chars = 25;
xlabel('Speed [rpm]')
ylabel('PV overlap ratio [%]')
title('PV overlap')
nicefigure(figure_purpose);

% plot all model datapoints. different color for each dataset.
for i=1:size(PV_overlap_ratio, 1)
    scatter([DATA_MOD(i).data.speedRPM], PV_overlap_ratio(i,:)*100, 40, 'x')
    legname = DATA_MOD(i).name;
    if length(legname)>leg_chars; legname = legname(1:leg_chars) + "..."; end
    legstr{i} = legname;

end
legend(legstr, 'Interpreter', 'none')

% scatter([RD_DATA.MB_speed], PV_overlap_ratio*100, 30, [RD_DATA.pmean]./1000,'x')



%% old plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% comparing MPSM PV plots
figure
hold on
legend
for i=1:2:length(MSPM_DATA)
   p_norm = MSPM_DATA(i).PV_PP.p - MSPM_DATA(i).p_mean;
    plot(MSPM_DATA(i).PV_PP.V, p_norm, 'DisplayName',num2str(round(MSPM_DATA(i).speedRPM)))
    x = input("");
end
% legend(num2str(round([MSPM_DATA.speedRPM]')))

%% Pmean over speed
figure
hold on
plot([RD_DATA.MB_speed], [RD_DATA.pmean], 'ok')
plot([MSPM_DATA.speedRPM], [MSPM_DATA.p_mean], 'xr')
xlabel('Speed [rpm]')
ylabel('Pressure [Pa]')
legend('Experiment','MSPM')
title('Mean Cycle Pressure, for mean pressures between 350kPa, 480kPa')

%% dP over speed
figure
hold on
plot([RD_DATA.MB_speed], max([RD_DATA.p_PC_avg])-min([RD_DATA.p_PC_avg]), 'ok')
PV_PP = [MSPM_DATA.PV_PP];
plot([MSPM_DATA.speedRPM], [PV_PP.deltaP], 'xr')
xlabel('Speed [rpm]')
ylabel('Pressure [Pa]')
legend('Experiment','MSPM')
title('delta-P, pmean 350...480kPa')





%% For comparing Sine and Crank $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
% Split MSPM_DATA into sine and crank
MSPM_SINE = MSPM_DATA(1:45);
MSPM_CRANK = MSPM_DATA(46:end);

%% Indicated Work vs speed, pressure as color
figure
hold on
% plot([RD_DATA.MB_speed], [RD_DATA.Wind_exp], 'ok')
% plot([MSPM_DATA.speedRPM], [MSPM_DATA.Wind], 'xr')
scatter([RD_DATA.MB_speed], [RD_DATA.Wind_exp], 30, [RD_DATA.pmean]./1000,'o')
scatter([RD_DATA.MB_speed], [MSPM_SINE.Wind], 30, [MSPM_SINE.p_mean]./1000,'x')
scatter([RD_DATA.MB_speed], [MSPM_CRANK.Wind], 20, [MSPM_CRANK.p_mean]./1000,'+')
% plot([RD_DATA.MB_speed], p_dev_mean*100, 'ok', [RD_DATA.MB_speed], p_dev_max*100, 'xr')
c = colorbar;
ylabel(c,'Mean Pressure (kPa)')
colormap(jet)
xlabel('Speed [rpm]')
ylabel('Indicated Work [J]')
legend('Experiment','MSPM-sine','MSPM-crank')
title('Indicated Work, for mean pressures between 350kPa, 480kPa')

%% Eff vs speed, pressure as color
eff_ind = [RD_DATA.Wind_exp].*[RD_DATA.MB_speed]./60 ./([RD_DATA.Qdot_heater_exp]+[RD_DATA.Qdot_DCH_exp]);

figure
hold on
% this is shaft efficiency
% scatter([RD_DATA.MB_speed], [RD_DATA.efficiency_exp], 30, [RD_DATA.pmean]./1000,'o')
scatter([RD_DATA.MB_speed], eff_ind, 30, [RD_DATA.pmean]./1000,'o')
scatter([RD_DATA.MB_speed], [MSPM_SINE.efficiency_ind]*100, 30, [MSPM_SINE.p_mean]./1000,'x')
scatter([RD_DATA.MB_speed], [MSPM_CRANK.efficiency_ind]*100, 20, [MSPM_CRANK.p_mean]./1000,'+')
c = colorbar;
ylabel(c,'Mean Pressure (kPa)')
colormap(jet)
xlabel('Speed [rpm]')
ylabel('Indicated Efficiency [%]')
legend('Experiment','MSPM-sine','MSPM-crank')
title('Efficiency, for mean pressures between 350kPa, 480kPa')

%% Avg and max deviation in pressure between exp and mod, vs speed, pressure as color
figure
hold on
scatter([RD_DATA.MB_speed], p_dev_mean(1:45)*100, 40, [RD_DATA.pmean]./1000,'x')
scatter([RD_DATA.MB_speed], p_dev_max(1:45)*100, 40, [RD_DATA.pmean]./1000,'x','LineWidth',1)
scatter([RD_DATA.MB_speed], p_dev_mean(46:end)*100, 30, [RD_DATA.pmean]./1000,'o')
scatter([RD_DATA.MB_speed], p_dev_max(46:end)*100, 30, [RD_DATA.pmean]./1000,'o','LineWidth',1)
% plot([RD_DATA.MB_speed], p_dev_mean*100, 'ok', [RD_DATA.MB_speed], p_dev_max*100, 'xr')
c = colorbar;
ylabel(c,'Mean Pressure (kPa)')
colormap(jet)
xlabel('Speed [rpm]')
ylabel('Pressure Relative Deviation [%]')
legend('Mean-sine','Max-sine','Mean-crank','Max-crank')
title('Deviation in pressure, pmean 350...480kPa')

%% PV overlap between exp and mod, vs speed, pressure as color
figure
hold on
% plot([RD_DATA.MB_speed], PV_overlap_ratio*100, 'xk')
scatter([RD_DATA.MB_speed], PV_overlap_ratio(1:45)*100, 40, [RD_DATA.pmean]./1000,'x')
scatter([RD_DATA.MB_speed], PV_overlap_ratio(46:end)*100, 30, [RD_DATA.pmean]./1000,'o')
c = colorbar;
ylabel(c,'Mean Pressure (kPa)')
colormap(jet)
xlabel('Speed [rpm]')
ylabel('PV overlap ratio [%]')
legend('sine','crank')
title('PV overlap, pmean 350...480kPa')

