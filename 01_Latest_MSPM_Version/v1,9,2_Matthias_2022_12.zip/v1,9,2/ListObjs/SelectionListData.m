classdef SelectionListData < handle

  properties
    ListObjs;
    Code;
  end
  
end

