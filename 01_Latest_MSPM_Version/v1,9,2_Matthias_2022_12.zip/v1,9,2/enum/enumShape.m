classdef enumShape
   enumeration
      Cylinder, Annulus, Cuboid
   end
end

