classdef enumMove
  enumeration
    Moving, Static, Stretching
  end
end

