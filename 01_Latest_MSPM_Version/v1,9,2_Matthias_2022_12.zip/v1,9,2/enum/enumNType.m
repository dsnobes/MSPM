classdef enumNType
   enumeration
      SVGN,...  Static Volume Gas Node
      VVGN,...Variable Volume Gas Node
      SAGN,...Shearing Annular Gas Node
      SN,...Solid Node
      EN %    Environment Node
   end
end

