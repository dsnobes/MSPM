classdef enumMatrix
  enumeration
    WovenScreen,
    RandomFiber,
    PackedSphere,
    StackedFoil,
    CustomRegen,
    HeatExchanger
  end
end

