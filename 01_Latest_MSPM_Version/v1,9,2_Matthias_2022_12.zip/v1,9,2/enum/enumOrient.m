classdef enumOrient
   enumeration
      Vertical, Horizontal
   end
end

