classdef enumMaterial
   enumeration
      Gas, Solid, Liquid
   end
end

