function output = z(input)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
output = 0;
end

