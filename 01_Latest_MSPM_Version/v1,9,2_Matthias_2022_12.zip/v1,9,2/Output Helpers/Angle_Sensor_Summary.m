AVG = mean(data.DependentVariable(:));
NAME = data.Name;