function [pos] = e12_n2_r2_Box(NAng, Phase)

end

