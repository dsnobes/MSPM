function [d] = Dist4Compare(A,B)
d = (A(1)-B(1))^2+(A(2)-B(2))^2;
end

