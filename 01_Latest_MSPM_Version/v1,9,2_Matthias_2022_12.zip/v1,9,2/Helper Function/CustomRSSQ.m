function [out] = CustomRSSQ(in)
    out = sqrt(sum(in.*in));
end

